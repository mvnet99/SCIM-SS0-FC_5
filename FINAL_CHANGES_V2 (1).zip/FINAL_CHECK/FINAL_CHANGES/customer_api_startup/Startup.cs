using API.Configurations;
using API.Helpers;
using API.Middleware;
using ApplicationInsightsTelemetry;
using AspNetCoreRateLimit;
using Domain.Constants;
using Domain.Helpers;
using Microsoft.ApplicationInsights.AspNetCore.Extensions;
using Microsoft.ApplicationInsights.DependencyCollector;
using Microsoft.ApplicationInsights.Extensibility;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.Features;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.FileProviders;
using Microsoft.Extensions.Hosting;
using Microsoft.Identity.Web;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using WIS_Utility.Logging;
using WS.FC.DatabaseService.Wrapper.Configuration;

namespace API
{
    public class Startup
    {
        public IConfiguration Configuration { get; }

        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public void ConfigureServices(IServiceCollection services)
        {
            // ── Authentication ────────────────────────────────────────────────
            // Single consolidated AddAuthentication call with 3 schemes.
            // Previous code had TWO AddAuthentication calls — the second silently
            // overwrote the first, meaning AzureAdJWT was never actually registered.
            // This fix preserves all existing functionality and adds SCIM support.
            //
            // Scheme 1 — AzureAdJWT:   Existing internal symmetric JWT (UI login)
            // Scheme 2 — B2CAll:        All B2C policies (existing + new HRD/SSO)
            //                           Same ClientId, same tenant, 3 policies all accepted
            // Scheme 3 — ScimOAuth: SCIM API → Customer API (B2C tenant, OAuth Client Credentials)
            services.AddAuthentication(options =>
            {
                options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
                options.DefaultChallengeScheme    = JwtBearerDefaults.AuthenticationScheme;
                options.DefaultScheme             = JwtBearerDefaults.AuthenticationScheme;
            })
            // ── Scheme 1: Internal symmetric JWT ─────────────────────────────
            // Used by internal login flow generating AzureAdJWT tokens.
            // Unchanged from original — same validation parameters.
            .AddJwtBearer("AzureAdJWT", options =>
            {
                options.SaveToken            = true;
                options.RequireHttpsMetadata = false;
                options.TokenValidationParameters = new TokenValidationParameters
                {
                    ValidateIssuer           = false,
                    ValidateAudience         = false,
                    ValidateLifetime         = true,
                    ValidateIssuerSigningKey = true,
                    ClockSkew                = TimeSpan.Zero,
                    ValidAudience            = Configuration["JwtSettings:ValidAudience"],
                    ValidIssuer              = Configuration["JwtSettings:ValidIssuer"],
                    IssuerSigningKey         = new SymmetricSecurityKey(
                        Encoding.UTF8.GetBytes(
                            KeyVaultSecretManager.GetSecretValueBySecretKey(
                                Configuration[WisAppConstants.JwtSecretKey])))
                };
            })
            // ── Scheme 2: B2C — ALL policies on same tenant ───────────────────
            // Covers existing B2C_1_SignInFlow_Both_B2C_B2B, B2C_1_SignInFlow_OnlyB2C,
            // and new B2C_1A_RIT-SignUpOrSignIn_HRD (Target/wisuk/WisIntl SSO).
            // All 3 use same ClientId and same B2C tenant — one scheme handles all.
            // KnownAuthorities ensures tokens from any policy on this tenant are trusted.
            .AddMicrosoftIdentityWebApi(
                jwtOptions => { },
                options =>
                {
                    options.ClientId             = KeyVaultSecretManager.GetSecretValueBySecretKey(WisAppConstants.AzureAdB2CClientId);
                    options.SignedOutCallbackPath = KeyVaultSecretManager.GetSecretValueBySecretKey(WisAppConstants.AzureAdB2CSignedOutCallbackPath);
                    options.Domain               = KeyVaultSecretManager.GetSecretValueBySecretKey(WisAppConstants.AzureAdB2CDomain);
                    options.Instance             = KeyVaultSecretManager.GetSecretValueBySecretKey(WisAppConstants.AzureAdB2CInstance);
                    options.SignUpSignInPolicyId  = KeyVaultSecretManager.GetSecretValueBySecretKey(WisAppConstants.AzureAdB2CSignUpSignInPolicyId);
                    // KnownAuthorities accepts tokens from ALL policies on this B2C tenant
                    options.KnownAuthorities.Add(
                        KeyVaultSecretManager.GetSecretValueBySecretKey(WisAppConstants.AzureAdB2CKnownAuthority));
                },
                jwtBearerScheme: "B2CAll")
            // ── Scheme 3: SCIM Managed Identity ──────────────────────────────
            // Used when SCIM API calls Customer API using its Managed Identity.
            // Token is issued by main WIS AD tenant (NOT B2C).
            // Validated by audience (Customer API app registration).
            // AuthorizationFilter bypasses emails claim check for this scheme
            // since machine-to-machine tokens carry appid claim, not emails.
            .AddJwtBearer("ScimOAuth", options =>
            {
                // SCIM API → Customer API via OAuth Client Credentials on B2C tenant.
                // Both apps registered on same B2C tenant (flexcountdev / 281fc3c7...).
                // Token issued by B2C underlying AD endpoint — same tenant as B2CAll scheme.
                // Authority uses B2C tenant ID directly — no main WIS AD tenant needed.
                var tenantId = KeyVaultSecretManager.GetSecretValueBySecretKey(WisAppConstants.AzureAdB2CTenantId);
                var clientId = KeyVaultSecretManager.GetSecretValueBySecretKey(WisAppConstants.CustomerApiClientId);
                options.Authority = $"https://login.microsoftonline.com/{tenantId}/v2.0";
                options.TokenValidationParameters = new TokenValidationParameters
                {
                    ValidateIssuer   = true,
                    ValidateAudience = true,
                    ValidAudience    = $"api://{clientId}",
                    ValidateLifetime = true
                };
            });

            // ── CORS ──────────────────────────────────────────────────────────
            var cors = Environment.GetEnvironmentVariable("AllowedOrigins").Split(',');
            services.AddCors(options =>
            {
                options.AddPolicy("AllRequests",
                    builder =>
                    {
                        builder.WithOrigins(cors)
                               .AllowAnyHeader()
                               .AllowAnyMethod()
                               .AllowCredentials();
                    });
            });

            services.Configure<FormOptions>(options =>
            {
                options.ValueLengthLimit            = int.MaxValue;
                options.MultipartBodyLengthLimit     = long.MaxValue;
                options.MultipartHeadersLengthLimit  = int.MaxValue;
            });

            services.Configure<IISServerOptions>(options =>
            {
                options.MaxRequestBodySize = long.MaxValue;
            });

            services.AddCORS();
            services.AddControllers();
            services.AddTransient<ResponseBodyLoggingMiddleware>();
            services.AddTransient<RequestBodyLoggingMiddleware>();
            services.AddMvc();
            services.AddAutoMapper(typeof(Domain.AutoMapperProfile));
            services.ConfigureRepositories();
            services.ConfigureServices();
            services.AddConnectionProvider(Configuration);
            services.AddAppSettings(Configuration);
            services.AddTransient<IHttpContextAccessor, HttpContextAccessor>();
            services.AddTransient<ITokenHelper, TokenHelper>();
            services.AddHttpContextAccessor();
            services.AddHttpClient();

            services.AddMemoryCache();
            services.Configure<IpRateLimitOptions>(options =>
            {
                options.EnableEndpointRateLimiting = true;
                options.StackBlockedRequests        = false;
                options.HttpStatusCode              = 429;
                options.RealIpHeader                = "X-Real-IP";
                options.ClientIdHeader              = "X-ClientId";
                options.GeneralRules = new List<RateLimitRule>
                {
                    new RateLimitRule
                    {
                        Endpoint = "POST:/customerapprestapi/api/user",
                        Period   = "10s",
                        Limit    = 1,
                    },
                    new RateLimitRule
                    {
                        Endpoint = "PUT:/customerapprestapi/api/user",
                        Period   = "10s",
                        Limit    = 1,
                    },
                };
            });

            ApplicationInsightsServiceOptions appInsightsOptions = new ApplicationInsightsServiceOptions();
            appInsightsOptions.ConnectionString =
                KeyVaultSecretManager.GetSecretValueBySecretKey(
                    Configuration[WisAppConstants.AppInsightsConnectionString]);

            services.AddApplicationInsightsTelemetry(appInsightsOptions);
            services.AddSingleton<ITelemetryInitializer, CloudRoleNameInitializer>();

            services.AddSingleton<IIpPolicyStore,           MemoryCacheIpPolicyStore>();
            services.AddSingleton<IRateLimitCounterStore,   MemoryCacheRateLimitCounterStore>();
            services.AddSingleton<IRateLimitConfiguration,  RateLimitConfiguration>();
            services.AddSingleton<IProcessingStrategy,      AsyncKeyLockProcessingStrategy>();
            services.AddInMemoryRateLimiting();

            services.AddDatabaseServiceDaprClients(
                KeyVaultSecretManager.GetSecretValueBySecretKey(WisAppConstants.InternalDataServiceUrlKey));

            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc(WisAppConstants.v1, new OpenApiInfo
                {
                    Title   = WisAppConstants.Title,
                    Version = WisAppConstants.v1
                });
                c.AddSecurityDefinition(WisAppConstants.Bearer, new OpenApiSecurityScheme
                {
                    In          = ParameterLocation.Header,
                    Description = WisAppConstants.Description,
                    Name        = WisAppConstants.Authorization,
                    Type        = SecuritySchemeType.ApiKey
                });
                c.AddSecurityRequirement(new OpenApiSecurityRequirement
                {
                    {
                        new OpenApiSecurityScheme
                        {
                            Reference = new OpenApiReference
                            {
                                Type = ReferenceType.SecurityScheme,
                                Id   = WisAppConstants.Bearer
                            }
                        },
                        Array.Empty<string>()
                    }
                });
            });

            // ── Authorization policies — all 3 schemes accepted ───────────────
            // AddAuthenticationSchemes ensures any of the 3 valid token types
            // can satisfy the policy. Existing role requirements unchanged.
            services.AddAuthorization(options =>
            {
                options.AddPolicy(PolicyConstants.AdminCorporateWisUser, policy => policy
                    .AddAuthenticationSchemes("AzureAdJWT", "B2CAll", "ScimOAuth")
                    .RequireAuthenticatedUser()
                    .RequireRole(PolicyConstants.Admin, PolicyConstants.Corporate, PolicyConstants.WisUser));

                options.AddPolicy(PolicyConstants.AdminWisUser, policy => policy
                    .AddAuthenticationSchemes("AzureAdJWT", "B2CAll", "ScimOAuth")
                    .RequireAuthenticatedUser()
                    .RequireRole(PolicyConstants.Admin, PolicyConstants.WisUser));

                options.AddPolicy(PolicyConstants.AdminCorporateRegionalWisUser, policy => policy
                    .AddAuthenticationSchemes("AzureAdJWT", "B2CAll", "ScimOAuth")
                    .RequireAuthenticatedUser()
                    .RequireRole(PolicyConstants.Admin, PolicyConstants.Corporate,
                                 PolicyConstants.Regional, PolicyConstants.WisUser));
            });

            services.ConfigureTelemetryModule<DependencyTrackingTelemetryModule>(
                (module, o) => { module.EnableSqlCommandTextInstrumentation = true; });
        }

        public void Configure(IApplicationBuilder app, IWebHostEnvironment env, AppSettings appSettings)
        {
            app.Use(async (context, next) =>
            {
                var httpMaxRequestBodySizeFeature =
                    context.Features.Get<IHttpMaxRequestBodySizeFeature>();

                if (httpMaxRequestBodySizeFeature is not null)
                    httpMaxRequestBodySizeFeature.MaxRequestBodySize = long.MaxValue;

                if (context.Request.Method == "TRACE"   ||
                    context.Request.Method == "PATCH"   ||
                    context.Request.Method == "CONNECT" ||
                    context.Request.Method == "HEAD")
                {
                    context.Response.StatusCode = 405;
                    return;
                }

                await next.Invoke();
            });

            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseStaticFiles(new StaticFileOptions
            {
                FileProvider = new PhysicalFileProvider(
                    Path.Combine(Directory.GetCurrentDirectory(), @"Resources")),
                RequestPath = new PathString("/Resources")
            });

            app.UseIpRateLimiting();
            app.UseMiddleware<ExceptionMiddleware>();
            app.UsePathBase(new PathString(WisAppConstants.PathString));

            app.UseSwagger();
            app.UseSwaggerUI(s =>
                s.SwaggerEndpoint(appSettings.StartUpSettings.SwaggerUrl, WisAppConstants.API));

            app.UseHttpsRedirection();
            app.UseRequestBodyLogging();
            app.UseResponseBodyLogging();
            app.UseStaticFiles();
            app.UseRouting();
            app.UseAuthentication();
            app.UseCors(WisAppConstants.CorsPolicy);
            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
                endpoints.MapControllerRoute("default", "{controller=Home}/{action=Index}/{id?}");
            });
        }
    }
}
