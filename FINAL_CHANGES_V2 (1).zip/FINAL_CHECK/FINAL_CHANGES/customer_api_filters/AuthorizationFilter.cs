using API.Helpers;
using Domain.Constants;
using Domain.Exceptions;
using Domain.Services.Interfaces;
using Microsoft.AspNetCore.Mvc.Filters;
using System;
using System.Linq;
using Domain.Services;

namespace API.Filters
{
    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Method)]
    public class AuthorizationFilterAttribute : Attribute, IAuthorizationFilter
    {
        protected readonly ITokenHelper _iTokenHelper;
        protected readonly ICustomerRefreshTokenService _customerRefreshTokenService;

        public AuthorizationFilterAttribute(
            ITokenHelper tokenHelper,
            ICustomerRefreshTokenService customerRefreshTokenService)
        {
            _iTokenHelper                = tokenHelper;
            _customerRefreshTokenService = customerRefreshTokenService;
        }

        public void OnAuthorization(AuthorizationFilterContext context)
        {
            // ── Not authenticated at all ──────────────────────────────────────
            if (!context.HttpContext.User.Identity.IsAuthenticated)
            {
                throw new InvalidTokenException(MessageConstants.InvalidAccessToken, null);
            }

            var claims = context.HttpContext.User.Claims?.ToList();

            if (claims == null)
            {
                throw new InvalidTokenException(MessageConstants.InvalidAccessToken, null);
            }

            // ── SCIM Managed Identity bypass ──────────────────────────────────
            // Machine-to-machine calls from SCIM API carry an 'appid' claim
            // (Managed Identity token from main WIS AD tenant).
            // These callers have no 'emails' claim — bypass the email check.
            // The token itself is already fully validated by ScimManagedIdentity
            // scheme in Startup.cs before reaching this filter.
            if (claims.Any(c => c.Type == "appid"))
            {
                return;
            }

            // ── B2C and AzureAdJWT user flows ─────────────────────────────────
            // All interactive user logins (existing B2C local accounts,
            // new HRD/SSO federated users via Target/wisuk/WisIntl) carry
            // the 'emails' claim issued by B2C after authentication.
            string azureAdEmail   = string.Empty;
            string azureAdIdentifier = string.Empty;

            if (claims.Any(l => l.Type.Equals("emails")))
            {
                azureAdEmail = claims
                    .FirstOrDefault(l => l.Type.Equals("emails"))?.Value
                    ?? string.Empty;
            }

            if (claims.Any(l => l.Type.Equals(
                "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/nameidentifier")))
            {
                var userAdIdentifier = claims.FirstOrDefault(l =>
                    l.Type.Equals(
                        "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/nameidentifier"));
                azureAdIdentifier = userAdIdentifier?.Value ?? string.Empty;
            }

            if (string.IsNullOrEmpty(azureAdEmail))
            {
                throw new UserNotFoundException(MessageConstants.azureUserNotFound, null);
            }
        }
    }
}
