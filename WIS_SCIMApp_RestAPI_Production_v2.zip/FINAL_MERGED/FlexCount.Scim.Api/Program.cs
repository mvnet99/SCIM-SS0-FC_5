using Azure.Identity;
using FlexCount.Scim.Api.Middleware;
using FlexCount.Scim.Domain.Services;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using Serilog;
using Serilog.Formatting.Compact;

// ── Serilog bootstrap (Datadog reads from stdout JSON) ───────────────────────
Log.Logger = new LoggerConfiguration()
    .WriteTo.Console(new CompactJsonFormatter())
    .CreateBootstrapLogger();

try
{
    var builder = WebApplication.CreateBuilder(args);

    // ── Key Vault configuration source ────────────────────────────────────────
    // KeyVaultUrl injected as Container App env var by SRE.
    // When present, all Key Vault secrets available via IConfiguration.
    // Locally empty — falls back to launchSettings env vars.
    var keyVaultUrl = builder.Configuration["KeyVaultUrl"];
    if (!string.IsNullOrEmpty(keyVaultUrl))
    {
        builder.Configuration.AddAzureKeyVault(
            new Uri(keyVaultUrl),
            new DefaultAzureCredential());
    }

    // ── Serilog ───────────────────────────────────────────────────────────────
    builder.Host.UseSerilog((ctx, services, config) =>
    {
        config
            .ReadFrom.Configuration(ctx.Configuration)
            .ReadFrom.Services(services)
            .Enrich.FromLogContext()
            .Enrich.WithProperty("Application", "FlexCount.Scim.Api")
            .Enrich.WithProperty("Environment", ctx.HostingEnvironment.EnvironmentName)
            .WriteTo.Console(new CompactJsonFormatter());
    });

    // ── Authentication: Dual-scheme — Static Bearer + OAuth JWT ──────────────
    //
    // INBOUND AUTH FLOWS (Target → SCIM API):
    //
    // Scheme 1 — StaticBearer (current default):
    //   Target pastes a static token into Entra provisioning screen.
    //   StaticBearerAuthHandler validates token, resolves customerId + serviceEmail from config.
    //   Config-driven — new customers added via env vars only, zero code changes.
    //
    // Scheme 2 — EntraOAuth (optional, for future Target switch):
    //   Target's Entra SCIM provisioning sends an OAuth JWT token.
    //   Validated against B2C tenant — issuer, audience, and lifetime checked.
    //   If Target switches to OAuth on their Entra config, no code changes needed.
    //   SRE must set: Scim:Inbound:TenantId and Scim:Inbound:Audience in Key Vault.
    //
    // ASP.NET Core tries StaticBearer first. If it fails → tries EntraOAuth.
    // If both fail → 401. Caller does not declare which scheme they use.
    //
    var inboundTenantId = builder.Configuration["Scim:Inbound:TenantId"];
    var inboundAudience = builder.Configuration["Scim:Inbound:Audience"];

    var authBuilder = builder.Services
        .AddAuthentication("StaticBearer")
        .AddScheme<Microsoft.AspNetCore.Authentication.AuthenticationSchemeOptions,
                   StaticBearerAuthHandler>("StaticBearer", null);

    // Only register EntraOAuth scheme if TenantId is configured.
    // This prevents startup failure in environments where OAuth is not yet set up.
    if (!string.IsNullOrEmpty(inboundTenantId))
    {
        authBuilder.AddJwtBearer("EntraOAuth", options =>
        {
            // Authority = B2C tenant underlying AD endpoint (not B2C policy URL)
            // This is the same tenant where SCIM App Registration lives.
            options.Authority = $"https://login.microsoftonline.com/{inboundTenantId}/v2.0";

            options.TokenValidationParameters = new TokenValidationParameters
            {
                ValidateIssuer   = true,
                ValidateAudience = true,
                ValidateLifetime = true,
                // Audience = SCIM API App Registration client ID (api://f32bc1e6...)
                // or configured explicitly via Scim:Inbound:Audience
                ValidAudience    = !string.IsNullOrEmpty(inboundAudience)
                                   ? inboundAudience
                                   : $"api://{inboundTenantId}",
            };

            // Log token validation events for Datadog observability
            options.Events = new JwtBearerEvents
            {
                OnAuthenticationFailed = ctx =>
                {
                    var logger = ctx.HttpContext.RequestServices
                        .GetRequiredService<ILogger<Program>>();
                    logger.LogWarning("EntraOAuth JWT validation failed: {Error}",
                        ctx.Exception.Message);
                    return Task.CompletedTask;
                },
                OnTokenValidated = ctx =>
                {
                    var logger = ctx.HttpContext.RequestServices
                        .GetRequiredService<ILogger<Program>>();
                    logger.LogInformation("EntraOAuth JWT validated — subject={Subject}",
                        ctx.Principal?.FindFirst("sub")?.Value);
                    return Task.CompletedTask;
                }
            };
        });
    }

    // ── Authorization — accepts either StaticBearer OR EntraOAuth ─────────────
    // Policy tries all registered schemes. First success = authenticated.
    builder.Services.AddAuthorization(options =>
    {
        var schemes = new List<string> { "StaticBearer" };
        if (!string.IsNullOrEmpty(inboundTenantId))
            schemes.Add("EntraOAuth");

        options.DefaultPolicy = new Microsoft.AspNetCore.Authorization.AuthorizationPolicyBuilder(
                schemes.ToArray())
            .RequireAuthenticatedUser()
            .Build();

        options.FallbackPolicy = options.DefaultPolicy;
    });

    // ── Health checks ─────────────────────────────────────────────────────────
    builder.Services.AddHealthChecks();

    // ── HttpClient + Polly for Customer API (outbound) ────────────────────────
    builder.Services.AddHttpClient<ICustomerApiService, CustomerApiService>()
        .AddPolicyHandler((services, _) =>
            PollyExtensions.GetRetryPolicy(
                services.GetRequiredService<ILogger<CustomerApiService>>()))
        .AddPolicyHandler(PollyExtensions.GetCircuitBreakerPolicy());

    builder.Services.AddControllers()
        .AddJsonOptions(opts =>
        {
            opts.JsonSerializerOptions.PropertyNamingPolicy   = System.Text.Json.JsonNamingPolicy.CamelCase;
            opts.JsonSerializerOptions.DefaultIgnoreCondition = System.Text.Json.Serialization.JsonIgnoreCondition.WhenWritingNull;
        });

    builder.Services.AddEndpointsApiExplorer();

    // ── Swagger with Bearer auth support ──────────────────────────────────────
    builder.Services.AddSwaggerGen(c =>
    {
        c.SwaggerDoc("v1", new OpenApiInfo
        {
            Title       = "FlexCount SCIM API",
            Version     = "v1",
            Description = "SCIM 2.0 provisioning API — RFC 7643/7644 compliant. " +
                          "Supports both Static Bearer Token and OAuth JWT inbound auth. " +
                          "Bridges Microsoft Entra ID provisioning with FlexCount Customer API."
        });

        c.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
        {
            In          = ParameterLocation.Header,
            Description = "Enter Static Bearer token or OAuth JWT token",
            Name        = "Authorization",
            Type        = SecuritySchemeType.ApiKey
        });

        c.AddSecurityRequirement(new OpenApiSecurityRequirement
        {
            {
                new OpenApiSecurityScheme
                {
                    Reference = new OpenApiReference
                    {
                        Type = ReferenceType.SecurityScheme,
                        Id   = "Bearer"
                    }
                },
                Array.Empty<string>()
            }
        });

        c.CustomSchemaIds(type =>
        {
            if (!type.IsGenericType) return type.Name;
            var baseName = type.Name[..type.Name.IndexOf('`')];
            var args     = string.Join("", type.GetGenericArguments().Select(t => t.Name));
            return $"{baseName}Of{args}";
        });
    });

    var app = builder.Build();

    // ── Middleware pipeline ───────────────────────────────────────────────────
    app.UseSerilogRequestLogging();
    app.UseMiddleware<ScimExceptionMiddleware>();

    app.UseSwagger();
    app.UseSwaggerUI(c =>
    {
        c.SwaggerEndpoint("/swagger/v1/swagger.json", "FlexCount SCIM API v1");
        c.RoutePrefix = "swagger";
    });

    app.UseAuthentication();
    app.UseAuthorization();
    app.MapControllers();
    app.MapHealthChecks("/HealthCheck");

    Log.Information("FlexCount SCIM API starting — inbound auth: StaticBearer{OAuthStatus}",
        !string.IsNullOrEmpty(inboundTenantId) ? " + EntraOAuth" : " only");
    app.Run();
}
catch (Exception ex)
{
    Log.Fatal(ex, "FlexCount SCIM API failed to start");
    throw;
}
finally
{
    Log.CloseAndFlush();
}
