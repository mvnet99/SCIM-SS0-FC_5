using Polly;
using Polly.Extensions.Http;
using Polly.Contrib.WaitAndRetry;

namespace FlexCount.Scim.Api.Extensions;

// FIX #10: Logger now injected directly into policy factory — WithLogger() extension
// wired correctly so retry warnings actually appear in Datadog.
// All Polly packages pinned to v7.x in .csproj — do NOT upgrade to v8 (breaking API).

public static class PollyExtensions
{
    /// <summary>
    /// FIX #10: ILogger injected via factory overload (services, request) in Program.cs.
    /// Exponential backoff with decorrelated jitter: ~2s, ~4s, ~8s.
    /// Only retries on transient HTTP errors and 503.
    /// </summary>
    public static IAsyncPolicy<HttpResponseMessage> GetRetryPolicy(ILogger logger)
    {
        var delay = Backoff.DecorrelatedJitterBackoffV2(
            medianFirstRetryDelay: TimeSpan.FromSeconds(2),
            retryCount: 3);

        return HttpPolicyExtensions
            .HandleTransientHttpError()
            .OrResult(r => r.StatusCode == System.Net.HttpStatusCode.ServiceUnavailable)
            .WaitAndRetryAsync(delay, onRetry: (outcome, timespan, retryAttempt, _) =>
            {
                // FIX #10: logger passed directly — no longer relies on Polly context lookup
                logger.LogWarning(
                    "Customer API retry {RetryAttempt} after {Delay}s - {Reason}",
                    retryAttempt,
                    timespan.TotalSeconds,
                    outcome.Exception?.Message ?? outcome.Result?.StatusCode.ToString());
            });
    }

    public static IAsyncPolicy<HttpResponseMessage> GetCircuitBreakerPolicy()
    {
        return HttpPolicyExtensions
            .HandleTransientHttpError()
            .CircuitBreakerAsync(
                handledEventsAllowedBeforeBreaking: 5,
                durationOfBreak: TimeSpan.FromSeconds(30));
    }
}
