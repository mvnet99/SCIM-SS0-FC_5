using Microsoft.AspNetCore.Authentication;
using Microsoft.Extensions.Options;
using System.Security.Claims;
using System.Text.Encodings.Web;

namespace FlexCount.Scim.Api.Middleware;

/// <summary>
/// Validates incoming static bearer tokens and resolves customer identity.
/// Token → Customer mapping is driven entirely by configuration (env vars / Key Vault).
/// No hardcoded customer values — SRE adds new customers via config only.
///
/// Config pattern (env vars injected by SRE):
///   Scim__Customers__Target__Token        = <bearer token from Key Vault>
///   Scim__Customers__Target__CustomerId   = TARGET001
///   Scim__Customers__Target__ServiceEmail = svc-target@flexcount.com
/// </summary>
public class StaticBearerAuthHandler : AuthenticationHandler<AuthenticationSchemeOptions>
{
    private readonly IConfiguration _config;

    public StaticBearerAuthHandler(
        IOptionsMonitor<AuthenticationSchemeOptions> options,
        ILoggerFactory logger,
        UrlEncoder encoder,
        IConfiguration config) : base(options, logger, encoder)
    {
        _config = config;
    }

    protected override Task<AuthenticateResult> HandleAuthenticateAsync()
    {
        var authHeader = Request.Headers["Authorization"].ToString();
        if (!authHeader.StartsWith("Bearer "))
            return Task.FromResult(AuthenticateResult.Fail("Missing Bearer token"));

        var incomingToken = authHeader["Bearer ".Length..].Trim();
        if (string.IsNullOrEmpty(incomingToken))
            return Task.FromResult(AuthenticateResult.Fail("Empty token"));

        // Resolve customer by matching incoming token against all configured customers
        var customerKey = ResolveCustomerKey(incomingToken);
        if (customerKey == null)
            return Task.FromResult(AuthenticateResult.Fail("Invalid token"));

        var customerId   = _config[$"Scim:Customers:{customerKey}:CustomerId"]   ?? string.Empty;
        var serviceEmail = _config[$"Scim:Customers:{customerKey}:ServiceEmail"] ?? string.Empty;

        if (string.IsNullOrEmpty(customerId) || string.IsNullOrEmpty(serviceEmail))
            return Task.FromResult(AuthenticateResult.Fail("Customer mapping incomplete"));

        var claims = new[]
        {
            new Claim(ClaimTypes.Name, customerKey),
            new Claim("customerId",    customerId),
            new Claim("serviceEmail",  serviceEmail)
        };

        var identity = new ClaimsIdentity(claims, Scheme.Name);
        var ticket   = new AuthenticationTicket(new ClaimsPrincipal(identity), Scheme.Name);
        return Task.FromResult(AuthenticateResult.Success(ticket));
    }

    /// <summary>
    /// Iterates all configured customer sections and returns the matching customer key.
    /// Returns null if no match found — results in 401.
    /// </summary>
    private string? ResolveCustomerKey(string incomingToken)
    {
        var customers = _config.GetSection("Scim:Customers").GetChildren();
        foreach (var customer in customers)
        {
            var configuredToken = customer["Token"];
            if (!string.IsNullOrEmpty(configuredToken) && incomingToken == configuredToken)
                return customer.Key;
        }
        return null;
    }
}
