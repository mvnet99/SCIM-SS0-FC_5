using FlexCount.Scim.Domain.Models.Scim;
using FlexCount.Scim.Domain.Services;
using FlexCount.Scim.Domain.Models.FlexCount;
using FlexCount.Scim.Domain.Transformers;

using System.Text.Json;

namespace FlexCount.Scim.Api.Middleware;

public class ScimExceptionMiddleware
{
    private readonly RequestDelegate _next;
    private readonly ILogger<ScimExceptionMiddleware> _logger;

    public ScimExceptionMiddleware(RequestDelegate next, ILogger<ScimExceptionMiddleware> logger)
    {
        _next   = next;
        _logger = logger;
    }

    public async Task InvokeAsync(HttpContext context)
    {
        try
        {
            await _next(context);
        }
        catch (UnauthorizedAccessException ex)
        {
            _logger.LogWarning(ex, "Unauthorized access attempt");
            await WriteScimError(context, 401, "Authentication required", null);
        }
        // FIX #8: ArgumentException from ParseEntitlement returns 400 invalidValue
        // Previously fell through to generic 500 — unhelpful and misleading
        catch (ArgumentException ex)
        {
            _logger.LogWarning(ex, "Invalid entitlement or argument in SCIM payload");
            await WriteScimError(context, 400, ex.Message, "invalidValue");
        }
        catch (HttpRequestException ex) when (ex.StatusCode == System.Net.HttpStatusCode.ServiceUnavailable)
        {
            _logger.LogError(ex, "Customer API unavailable after retries");
            context.Response.Headers["Retry-After"] = "60";
            await WriteScimError(context, 503, "Downstream service unavailable. Please retry.", null);
        }
        catch (HttpRequestException ex) when (ex.StatusCode == System.Net.HttpStatusCode.Conflict)
        {
            await WriteScimError(context, 409, "Resource conflict", "uniqueness");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Unhandled exception in SCIM API");
            await WriteScimError(context, 500, "An internal error occurred", null);
        }
    }

    private static async Task WriteScimError(HttpContext context, int status, string detail, string? scimType)
    {
        context.Response.StatusCode  = status;
        context.Response.ContentType = "application/scim+json";
        var error = new ScimError { Status = status, Detail = detail, ScimType = scimType };
        await context.Response.WriteAsync(JsonSerializer.Serialize(error,
            new JsonSerializerOptions { PropertyNamingPolicy = JsonNamingPolicy.CamelCase }));
    }
}
