using Azure.Identity;
using FlexCount.Scim.Api.Middleware;
using FlexCount.Scim.Domain.Services;
using Microsoft.OpenApi.Models;
using Serilog;
using Serilog.Formatting.Compact;

// ── Serilog bootstrap (Datadog reads from stdout JSON) ───────────────────────
Log.Logger = new LoggerConfiguration()
    .WriteTo.Console(new CompactJsonFormatter())
    .CreateBootstrapLogger();

try
{
    var builder = WebApplication.CreateBuilder(args);

    // ── Key Vault configuration source ────────────────────────────────────────
    // KeyVaultUrl injected as Container App env var by SRE.
    // When present, all Key Vault secrets available via IConfiguration.
    // Locally empty — falls back to launchSettings env vars.
    var keyVaultUrl = builder.Configuration["KeyVaultUrl"];
    if (!string.IsNullOrEmpty(keyVaultUrl))
    {
        builder.Configuration.AddAzureKeyVault(
            new Uri(keyVaultUrl),
            new DefaultAzureCredential());
    }

    // ── Serilog ───────────────────────────────────────────────────────────────
    builder.Host.UseSerilog((ctx, services, config) =>
    {
        config
            .ReadFrom.Configuration(ctx.Configuration)
            .ReadFrom.Services(services)
            .Enrich.FromLogContext()
            .Enrich.WithProperty("Application", "FlexCount.Scim.Api")
            .Enrich.WithProperty("Environment", ctx.HostingEnvironment.EnvironmentName)
            .WriteTo.Console(new CompactJsonFormatter());
    });

    // ── Authentication: Static Bearer Token ───────────────────────────────────
    // Token → customer resolution handled in StaticBearerAuthHandler.
    // Customer config (token, customerId, serviceEmail) injected via Key Vault / env vars.
    // No hardcoded values — adding a new customer = SRE adds 3 env vars, zero code changes.
    builder.Services.AddAuthentication("StaticBearer")
        .AddScheme<Microsoft.AspNetCore.Authentication.AuthenticationSchemeOptions,
                   StaticBearerAuthHandler>("StaticBearer", null);

    builder.Services.AddAuthorization();

    // ── Health checks ─────────────────────────────────────────────────────────
    builder.Services.AddHealthChecks();

    // ── HttpClient + Polly for Customer API (outbound) ────────────────────────
    builder.Services.AddHttpClient<ICustomerApiService, CustomerApiService>()
        .AddPolicyHandler((services, _) =>
            PollyExtensions.GetRetryPolicy(
                services.GetRequiredService<ILogger<CustomerApiService>>()))
        .AddPolicyHandler(PollyExtensions.GetCircuitBreakerPolicy());

    builder.Services.AddControllers()
        .AddJsonOptions(opts =>
        {
            opts.JsonSerializerOptions.PropertyNamingPolicy   = System.Text.Json.JsonNamingPolicy.CamelCase;
            opts.JsonSerializerOptions.DefaultIgnoreCondition = System.Text.Json.Serialization.JsonIgnoreCondition.WhenWritingNull;
        });

    builder.Services.AddEndpointsApiExplorer();

    // ── Swagger with Bearer auth support ──────────────────────────────────────
    builder.Services.AddSwaggerGen(c =>
    {
        c.SwaggerDoc("v1", new OpenApiInfo
        {
            Title   = "FlexCount SCIM API",
            Version = "v1",
            Description = "SCIM 2.0 provisioning API — RFC 7643/7644 compliant. " +
                          "Bridges Microsoft Entra ID provisioning with FlexCount Customer API."
        });

        c.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
        {
            In          = ParameterLocation.Header,
            Description = "Enter your Bearer token",
            Name        = "Authorization",
            Type        = SecuritySchemeType.ApiKey
        });

        c.AddSecurityRequirement(new OpenApiSecurityRequirement
        {
            {
                new OpenApiSecurityScheme
                {
                    Reference = new OpenApiReference
                    {
                        Type = ReferenceType.SecurityScheme,
                        Id   = "Bearer"
                    }
                },
                Array.Empty<string>()
            }
        });

        // Prevents generic schema name collisions for generic types
        c.CustomSchemaIds(type =>
        {
            if (!type.IsGenericType) return type.Name;
            var baseName = type.Name[..type.Name.IndexOf('`')];
            var args     = string.Join("", type.GetGenericArguments().Select(t => t.Name));
            return $"{baseName}Of{args}";
        });
    });

    var app = builder.Build();

    // ── Middleware pipeline ───────────────────────────────────────────────────
    app.UseSerilogRequestLogging();
    app.UseMiddleware<ScimExceptionMiddleware>();

    app.UseSwagger();
    app.UseSwaggerUI(c =>
    {
        c.SwaggerEndpoint("/swagger/v1/swagger.json", "FlexCount SCIM API v1");
        c.RoutePrefix = "swagger";
    });

    app.UseAuthentication();
    app.UseAuthorization();
    app.MapControllers();
    app.MapHealthChecks("/HealthCheck");

    Log.Information("FlexCount SCIM API starting");
    app.Run();
}
catch (Exception ex)
{
    Log.Fatal(ex, "FlexCount SCIM API failed to start");
    throw;
}
finally
{
    Log.CloseAndFlush();
}
