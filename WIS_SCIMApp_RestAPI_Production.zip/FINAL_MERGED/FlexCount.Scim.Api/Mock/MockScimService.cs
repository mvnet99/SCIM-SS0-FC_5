using FlexCount.Scim.Domain.Models.FlexCount;
using FlexCount.Scim.Domain.Models.Scim;
using System.Collections.Concurrent;
using System.Text.Json;

namespace FlexCount.Scim.Api.Mock;

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// TEMPORARY MOCK — Remove this file and revert UsersController mock blocks
// to _customerApi calls when Customer API wiring is ready.
//
// This mock is Entra SCIM validator compliant:
// - ConcurrentDictionary for thread-safe in-memory user storage
// - MockUser internal class preserves full SCIM collections (emails/phones/roles)
// - GetScimUserByEmail returns full SCIM structure bypassing ScimTransformer
// - LogAndMockPatch handles path-based AND value-object PATCH operations
// - Lists copied by value to prevent shared-reference mutation bugs
// - Fallback to first item when Primary flag not set (BooleanStringConverter edge case)
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

public static class MockScimService
{
    // ── Hardcoded seed users — 1 Admin, 1 Corporate, 1 Regional @target.com ──
    private static readonly List<FlexCountUser> HardcodedUsers = new()
    {
        new FlexCountUser
        {
            Id        = "admin.user@target.com",
            Email     = "admin.user@target.com",
            FirstName = "Admin",
            LastName  = "User",
            UserType  = "Admin",
            Status    = "Active",
            CreatedAt = new DateTime(2024, 1, 1, 0, 0, 0, DateTimeKind.Utc),
            UpdatedAt = new DateTime(2024, 1, 1, 0, 0, 0, DateTimeKind.Utc)
        },
        new FlexCountUser
        {
            Id        = "corporate.user@target.com",
            Email     = "corporate.user@target.com",
            FirstName = "Corporate",
            LastName  = "User",
            UserType  = "Corporate",
            Status    = "Active",
            CreatedAt = new DateTime(2024, 1, 1, 0, 0, 0, DateTimeKind.Utc),
            UpdatedAt = new DateTime(2024, 1, 1, 0, 0, 0, DateTimeKind.Utc)
        },
        new FlexCountUser
        {
            Id        = "regional.user@target.com",
            Email     = "regional.user@target.com",
            FirstName = "Regional",
            LastName  = "User",
            UserType  = "Regional",
            Status    = "Active",
            CreatedAt = new DateTime(2024, 1, 1, 0, 0, 0, DateTimeKind.Utc),
            UpdatedAt = new DateTime(2024, 1, 1, 0, 0, 0, DateTimeKind.Utc)
        }
    };

    // ── In-memory store for dynamically created/patched users (thread-safe) ───
    // Keyed by email lowercased. Resets on container restart — acceptable for mock.
    private static readonly ConcurrentDictionary<string, MockUser> _dynamicUsers
        = new(StringComparer.OrdinalIgnoreCase);

    // ── Internal rich user model — preserves full SCIM collections ───────────
    // FlexCountUser only holds flat fields — MockUser retains emails/phones/roles
    // so GET responses after POST/PATCH return accurate SCIM payloads.
    private class MockUser
    {
        public string   Email        { get; set; } = string.Empty;
        public string   FirstName    { get; set; } = string.Empty;
        public string   LastName     { get; set; } = string.Empty;
        public string   UserType     { get; set; } = string.Empty;
        public bool     Active       { get; set; } = true;
        public DateTime CreatedAt    { get; set; } = DateTime.UtcNow;
        public DateTime UpdatedAt    { get; set; } = DateTime.UtcNow;
        public List<ScimEmail>       Emails       { get; set; } = new();
        public List<ScimPhoneNumber> PhoneNumbers { get; set; } = new();
        public List<ScimRole>        Roles        { get; set; } = new();
    }

    // ── GET list — merges hardcoded + dynamic users ───────────────────────────
    public static (List<FlexCountUser> Users, int TotalCount) GetAllUsers()
    {
        var dynamic = _dynamicUsers.Values.Select(ToFlexCountUser).ToList();
        var all     = HardcodedUsers.Concat(dynamic).ToList();
        return (all, all.Count);
    }

    // ── GET by email — checks dynamic store first, then hardcoded ─────────────
    public static FlexCountUser? GetUserByEmail(string email)
    {
        if (_dynamicUsers.TryGetValue(email, out var dynamic))
            return ToFlexCountUser(dynamic);

        return HardcodedUsers.FirstOrDefault(u =>
            u.Email.Equals(email, StringComparison.OrdinalIgnoreCase));
    }

    // ── GET full SCIM structure — bypasses ScimTransformer for validator accuracy
    public static ScimUser? GetScimUserByEmail(string email, string baseUrl)
    {
        if (_dynamicUsers.TryGetValue(email, out var dynamic))
            return ToScimUser(dynamic, baseUrl);
        return null;
    }

    // ── Duplicate check — used by UsersController before POST ─────────────────
    public static bool UserExists(string email)
        => _dynamicUsers.ContainsKey(email) ||
           HardcodedUsers.Any(u => u.Email.Equals(email, StringComparison.OrdinalIgnoreCase));

    // ── POST — stores full SCIM data in dynamic store ─────────────────────────
    public static FlexCountUser LogAndMockCreate(ScimUser scimUser, ILogger logger)
    {
        logger.LogInformation(
            "MOCK SCIM CREATE received — {@ScimUser}",
            new
            {
                scimUser.UserName,
                Name         = new { scimUser.Name?.GivenName, scimUser.Name?.FamilyName },
                Emails       = scimUser.Emails?.Select(e => new { e.Value, e.Type, e.Primary }),
                PhoneNumbers = scimUser.PhoneNumbers?.Select(p => new { p.Value, p.Type, p.Primary }),
                scimUser.Active,
                Roles        = scimUser.Roles?.Select(r => new { r.Value, r.Primary })
            });

        var now  = DateTime.UtcNow;
        var mock = new MockUser
        {
            Email        = scimUser.UserName ?? string.Empty,
            FirstName    = scimUser.Name?.GivenName  ?? string.Empty,
            LastName     = scimUser.Name?.FamilyName ?? string.Empty,
            UserType     = scimUser.Roles?.FirstOrDefault(r => r.Primary)?.Value
                           ?? scimUser.Roles?.FirstOrDefault()?.Value
                           ?? "Corporate",
            Active       = scimUser.Active,
            CreatedAt    = now,
            UpdatedAt    = now,
            Emails       = scimUser.Emails       ?? new(),
            PhoneNumbers = scimUser.PhoneNumbers ?? new(),
            Roles        = scimUser.Roles        ?? new()
        };

        _dynamicUsers[mock.Email] = mock;
        return ToFlexCountUser(mock);
    }

    // ── PATCH — handles path-based AND value-object operations ────────────────
    // Lists are copied by value to prevent shared-reference mutation bugs.
    // Fallback to FirstOrDefault() when Primary flag unreliable (string "true" edge case).
    public static FlexCountUser LogAndMockPatch(
        string email, ScimPatchRequest patchRequest, ILogger logger)
    {
        logger.LogInformation(
            "MOCK SCIM PATCH received — Email={Email} Operations={@Operations}",
            email,
            patchRequest.Operations.Select(op => new { op.Op, op.Path, Value = op.Value?.ToString() }));

        // Resolve existing user — dynamic first, then hardcoded skeleton
        var existing = _dynamicUsers.TryGetValue(email, out var dyn)
            ? dyn
            : HardcodedUsers.FirstOrDefault(u =>
                u.Email.Equals(email, StringComparison.OrdinalIgnoreCase)) is { } hc
                ? new MockUser
                {
                    Email     = hc.Email,
                    FirstName = hc.FirstName,
                    LastName  = hc.LastName,
                    UserType  = hc.UserType,
                    Active    = hc.Status == "Active",
                    CreatedAt = hc.CreatedAt ?? DateTime.UtcNow,
                    UpdatedAt = DateTime.UtcNow
                }
                : new MockUser { Email = email };

        // Copy by value — prevents shared-reference mutation bugs under concurrent load
        var updated = new MockUser
        {
            Email     = existing.Email,
            FirstName = existing.FirstName,
            LastName  = existing.LastName,
            UserType  = existing.UserType,
            Active    = existing.Active,
            CreatedAt = existing.CreatedAt,
            UpdatedAt = DateTime.UtcNow,
            Emails = existing.Emails.Select(e => new ScimEmail
                { Value = e.Value, Type = e.Type, Primary = e.Primary }).ToList(),
            PhoneNumbers = existing.PhoneNumbers.Select(p => new ScimPhoneNumber
                { Value = p.Value, Type = p.Type, Primary = p.Primary }).ToList(),
            Roles = existing.Roles.Select(r => new ScimRole
                { Value = r.Value, Display = r.Display, Primary = r.Primary }).ToList()
        };

        foreach (var op in patchRequest.Operations)
        {
            var opLower = op.Op.ToLower();
            var path    = op.Path?.ToLower() ?? string.Empty;

            // ── Path-based operations ─────────────────────────────────────────
            if (!string.IsNullOrEmpty(path))
            {
                var val = op.Value?.ToString();

                switch (path)
                {
                    case "active":
                        if (bool.TryParse(val, out var active))
                            updated.Active = active;
                        break;

                    case "name.givenname":
                        updated.FirstName = opLower == "remove" ? string.Empty : val ?? updated.FirstName;
                        break;

                    case "name.familyname":
                        updated.LastName = opLower == "remove" ? string.Empty : val ?? updated.LastName;
                        break;

                    case "emails[primary eq true].value":
                        // Fallback to first if Primary not reliably set
                        var pEmail = updated.Emails.FirstOrDefault(e => e.Primary)
                                     ?? updated.Emails.FirstOrDefault();
                        if (pEmail != null) pEmail.Value = val;
                        break;

                    case "phonenumbers[primary eq true].value":
                        var pPhone = updated.PhoneNumbers.FirstOrDefault(p => p.Primary)
                                     ?? updated.PhoneNumbers.FirstOrDefault();
                        if (pPhone != null) pPhone.Value = val;
                        else updated.PhoneNumbers.Add(
                            new ScimPhoneNumber { Value = val, Type = "work", Primary = true });
                        break;

                    case "roles[primary eq true].value":
                        var pRole = updated.Roles.FirstOrDefault(r => r.Primary)
                                    ?? updated.Roles.FirstOrDefault();
                        if (pRole != null) pRole.Value = val;
                        break;
                }
            }
            // ── Value-object operations (no path — value is a JSON object) ────
            // Entra sends: {"op":"replace","value":{"name.givenName":"X","active":true}}
            else if (op.Value is JsonElement je && je.ValueKind == JsonValueKind.Object)
            {
                foreach (var prop in je.EnumerateObject())
                {
                    switch (prop.Name.ToLower())
                    {
                        case "username":
                            var newEmail = prop.Value.GetString() ?? updated.Email;
                            _dynamicUsers.TryRemove(updated.Email, out _);
                            // Sync primary email value to new userName
                            var syncEmail = updated.Emails.FirstOrDefault(e => e.Primary)
                                            ?? updated.Emails.FirstOrDefault();
                            if (syncEmail != null) syncEmail.Value = newEmail;
                            updated.Email = newEmail;
                            break;

                        case "name.givenname":
                            updated.FirstName = prop.Value.GetString() ?? updated.FirstName;
                            break;

                        case "name.familyname":
                            updated.LastName = prop.Value.GetString() ?? updated.LastName;
                            break;

                        case "active":
                            updated.Active =
                                prop.Value.ValueKind == JsonValueKind.True ||
                                (prop.Value.ValueKind == JsonValueKind.String &&
                                 bool.TryParse(prop.Value.GetString(), out var av) && av);
                            break;
                    }
                }
            }
        }

        _dynamicUsers[updated.Email] = updated;
        return ToFlexCountUser(updated);
    }

    // ── DELETE ────────────────────────────────────────────────────────────────
    public static void DeleteUser(string email)
        => _dynamicUsers.TryRemove(email, out _);

    // ── Private converters ────────────────────────────────────────────────────

    private static FlexCountUser ToFlexCountUser(MockUser m) => new()
    {
        Id        = m.Email,
        Email     = m.Email,
        FirstName = m.FirstName,
        LastName  = m.LastName,
        UserType  = m.UserType,
        Status    = m.Active ? "Active" : "Inactive",
        CreatedAt = m.CreatedAt,
        UpdatedAt = m.UpdatedAt
    };

    private static ScimUser ToScimUser(MockUser m, string baseUrl) => new()
    {
        Id           = m.Email,
        UserName     = m.Email,
        Name         = new ScimName { GivenName = m.FirstName, FamilyName = m.LastName },
        Emails       = m.Emails.Any()
                       ? m.Emails
                       : new List<ScimEmail> { new() { Value = m.Email, Type = "work", Primary = true } },
        PhoneNumbers = m.PhoneNumbers,
        Active       = m.Active,
        Roles        = m.Roles.Any()
                       ? m.Roles
                       : new List<ScimRole> { new() { Value = m.UserType, Primary = true } },
        Meta = new ScimMeta
        {
            ResourceType = "User",
            Created      = m.CreatedAt,
            LastModified = m.UpdatedAt,
            Location     = $"{baseUrl}/scim/v2/Users/{Uri.EscapeDataString(m.Email)}",
            Version      = $"W/\"{m.UpdatedAt.Ticks}\""
        }
    };
}
