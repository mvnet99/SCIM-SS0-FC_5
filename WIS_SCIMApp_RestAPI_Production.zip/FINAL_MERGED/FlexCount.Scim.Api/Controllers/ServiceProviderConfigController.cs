using Microsoft.AspNetCore.Mvc;

namespace FlexCount.Scim.Api.Controllers;

/// <summary>
/// SCIM 2.0 RFC 7643 discovery endpoints.
/// No auth required — Entra ID reads these to understand supported capabilities.
/// All attributes include required RFC 7643 §8.7 fields:
/// multiValued, mutability, returned, uniqueness.
/// </summary>
[ApiController]
[Route("scim/v2")]
[Produces("application/scim+json")]
public class ServiceProviderConfigController : ControllerBase
{
    // GET /scim/v2/ServiceProviderConfig
    [HttpGet("ServiceProviderConfig")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    public IActionResult GetServiceProviderConfig()
    {
        return Ok(new
        {
            schemas        = new[] { "urn:ietf:params:scim:schemas:core:2.0:ServiceProviderConfig" },
            patch          = new { supported = true },
            bulk           = new { supported = false, maxOperations = 0, maxPayloadSize = 0 },
            filter         = new { supported = true, maxResults = 200 },
            changePassword = new { supported = false },
            sort           = new { supported = false },
            etag           = new { supported = true },
            authenticationSchemes = new[]
            {
                new
                {
                    name        = "OAuth Bearer Token",
                    description = "Azure AD OAuth2 Bearer Token (RFC 6750)",
                    type        = "oauthbearertoken",
                    primary     = true
                }
            },
            meta = new
            {
                resourceType = "ServiceProviderConfig",
                location     = $"{Request.Scheme}://{Request.Host}/scim/v2/ServiceProviderConfig"
            }
        });
    }

    // GET /scim/v2/ResourceTypes
    [HttpGet("ResourceTypes")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    public IActionResult GetResourceTypes()
    {
        return Ok(new
        {
            schemas      = new[] { "urn:ietf:params:scim:api:messages:2.0:ListResponse" },
            totalResults = 1,
            Resources    = new[]
            {
                new
                {
                    schemas     = new[] { "urn:ietf:params:scim:schemas:core:2.0:ResourceType" },
                    id          = "User",
                    name        = "User",
                    endpoint    = "/scim/v2/Users",
                    description = "FlexCount User Account",
                    schema      = "urn:ietf:params:scim:schemas:core:2.0:User",
                    meta = new
                    {
                        resourceType = "ResourceType",
                        location     = $"{Request.Scheme}://{Request.Host}/scim/v2/ResourceTypes/User"
                    }
                }
            }
        });
    }

    // GET /scim/v2/Schemas
    // RFC 7643 §8.7 — each attribute MUST include:
    // name, type, multiValued, description, required, mutability, returned, uniqueness
    [HttpGet("Schemas")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    public IActionResult GetSchemas()
    {
        return Ok(new
        {
            schemas      = new[] { "urn:ietf:params:scim:api:messages:2.0:ListResponse" },
            totalResults = 1,
            Resources    = new object[]
            {
                new
                {
                    id          = "urn:ietf:params:scim:schemas:core:2.0:User",
                    name        = "User",
                    description = "FlexCount SCIM User Schema",
                    schemas     = new[] { "urn:ietf:params:scim:schemas:core:2.0:Schema" },
                    meta = new
                    {
                        resourceType = "Schema",
                        location     = $"{Request.Scheme}://{Request.Host}/scim/v2/Schemas/urn:ietf:params:scim:schemas:core:2.0:User"
                    },
                    attributes = new object[]
                    {
                        new
                        {
                            name        = "userName",
                            type        = "string",
                            multiValued = false,
                            description = "User email address — immutable, unique per customer. Used as SCIM id.",
                            required    = true,
                            mutability  = "readWrite",
                            returned    = "default",
                            uniqueness  = "server"
                        },
                        new
                        {
                            name        = "name",
                            type        = "complex",
                            multiValued = false,
                            description = "User name with givenName and familyName sub-attributes.",
                            required    = false,
                            mutability  = "readWrite",
                            returned    = "default",
                            uniqueness  = "none",
                            subAttributes = new object[]
                            {
                                new
                                {
                                    name        = "givenName",
                                    type        = "string",
                                    multiValued = false,
                                    description = "First name.",
                                    required    = false,
                                    mutability  = "readWrite",
                                    returned    = "default",
                                    uniqueness  = "none"
                                },
                                new
                                {
                                    name        = "familyName",
                                    type        = "string",
                                    multiValued = false,
                                    description = "Last name.",
                                    required    = false,
                                    mutability  = "readWrite",
                                    returned    = "default",
                                    uniqueness  = "none"
                                }
                            }
                        },
                        new
                        {
                            name        = "emails",
                            type        = "complex",
                            multiValued = true,
                            description = "User email addresses.",
                            required    = true,
                            mutability  = "readWrite",
                            returned    = "default",
                            uniqueness  = "none",
                            subAttributes = new object[]
                            {
                                new
                                {
                                    name        = "value",
                                    type        = "string",
                                    multiValued = false,
                                    description = "Email address value.",
                                    required    = false,
                                    mutability  = "readWrite",
                                    returned    = "default",
                                    uniqueness  = "none"
                                },
                                new
                                {
                                    name        = "type",
                                    type        = "string",
                                    multiValued = false,
                                    description = "Email type e.g. work, home.",
                                    required    = false,
                                    mutability  = "readWrite",
                                    returned    = "default",
                                    uniqueness  = "none"
                                },
                                new
                                {
                                    name        = "primary",
                                    type        = "boolean",
                                    multiValued = false,
                                    description = "Indicates primary email.",
                                    required    = false,
                                    mutability  = "readWrite",
                                    returned    = "default",
                                    uniqueness  = "none"
                                }
                            }
                        },
                        new
                        {
                            name        = "phoneNumbers",
                            type        = "complex",
                            multiValued = true,
                            description = "Primary and secondary phones. Type: Mobile | Home | Office.",
                            required    = false,
                            mutability  = "readWrite",
                            returned    = "default",
                            uniqueness  = "none",
                            subAttributes = new object[]
                            {
                                new
                                {
                                    name        = "value",
                                    type        = "string",
                                    multiValued = false,
                                    description = "Phone number value.",
                                    required    = false,
                                    mutability  = "readWrite",
                                    returned    = "default",
                                    uniqueness  = "none"
                                },
                                new
                                {
                                    name        = "type",
                                    type        = "string",
                                    multiValued = false,
                                    description = "Phone type: Mobile, Home, Office.",
                                    required    = false,
                                    mutability  = "readWrite",
                                    returned    = "default",
                                    uniqueness  = "none"
                                },
                                new
                                {
                                    name        = "primary",
                                    type        = "boolean",
                                    multiValued = false,
                                    description = "Indicates primary phone.",
                                    required    = false,
                                    mutability  = "readWrite",
                                    returned    = "default",
                                    uniqueness  = "none"
                                }
                            }
                        },
                        new
                        {
                            name        = "active",
                            type        = "boolean",
                            multiValued = false,
                            description = "Maps to Active/Inactive status in FlexCount. false = soft deactivation.",
                            required    = true,
                            mutability  = "readWrite",
                            returned    = "default",
                            uniqueness  = "none"
                        },
                        new
                        {
                            name        = "roles",
                            type        = "complex",
                            multiValued = true,
                            description = "Entitlement role. Value pattern: APP-FlexCount-{type}-{env}. Determines userType and regional group.",
                            required    = false,
                            mutability  = "readWrite",
                            returned    = "default",
                            uniqueness  = "none",
                            subAttributes = new object[]
                            {
                                new
                                {
                                    name        = "value",
                                    type        = "string",
                                    multiValued = false,
                                    description = "Role value e.g. Admin, Corporate, Regional.",
                                    required    = false,
                                    mutability  = "readWrite",
                                    returned    = "default",
                                    uniqueness  = "none"
                                },
                                new
                                {
                                    name        = "primary",
                                    type        = "boolean",
                                    multiValued = false,
                                    description = "Indicates primary role.",
                                    required    = false,
                                    mutability  = "readWrite",
                                    returned    = "default",
                                    uniqueness  = "none"
                                }
                            }
                        }
                    }
                }
            }
        });
    }
}