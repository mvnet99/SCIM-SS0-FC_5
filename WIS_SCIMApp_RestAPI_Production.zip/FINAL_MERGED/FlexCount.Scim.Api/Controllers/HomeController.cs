﻿using Microsoft.AspNetCore.Mvc;

namespace FlexCount.Scim.Api.Controllers
{
   // [Route("api/[controller]")]
    [ApiController]
    public class HomeController : ControllerBase
    {
        [ApiExplorerSettings(IgnoreApi = true)]
        [HttpGet("/")]
        public IActionResult Index()
        {
            try
            {
                var uri = new Uri("/swagger", UriKind.Relative);
                return Redirect(uri.ToString());
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex);
            }
        }

        [HttpGet("HealthCheck")]
        public IActionResult Healthcheck()
        {
            return Ok("FlexCount SCIM API is healthy");
        }
    }
}
