using FlexCount.Scim.Api.Mock;
using FlexCount.Scim.Domain.Models.Scim;
using FlexCount.Scim.Domain.Models.FlexCount;
using FlexCount.Scim.Domain.Services;
using FlexCount.Scim.Domain.Transformers;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace FlexCount.Scim.Api.Controllers;

[ApiController]
[Route("scim/v2/[controller]")]
[Authorize]
[Produces("application/scim+json")]
public class UsersController : ControllerBase
{
    private readonly ICustomerApiService _customerApi;
    private readonly ILogger<UsersController> _logger;

    public UsersController(ICustomerApiService customerApi, ILogger<UsersController> logger)
    {
        _customerApi = customerApi;
        _logger      = logger;
    }

    // GET /scim/v2/Users?filter=userName eq "email"  — Entra lookup before create
    // GET /scim/v2/Users?startIndex=1&count=100      — paged enumeration
    [HttpGet]
    [ProducesResponseType(typeof(ScimListResponse<ScimUser>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ScimError), StatusCodes.Status400BadRequest)]
    public async Task<IActionResult> GetUsers(
        [FromQuery] string? filter,
        [FromQuery] int startIndex = 1,
        [FromQuery] int count      = 100)
    {
        var (customerId, serviceAccount) = ExtractClaims();
        _logger.LogInformation(
            "SCIM GET /Users filter={Filter} startIndex={StartIndex} count={Count} customer={CustomerId}",
            filter, startIndex, count, customerId);

        if (!string.IsNullOrEmpty(filter))
        {
            if (filter.StartsWith("userName eq ", StringComparison.OrdinalIgnoreCase))
            {
                var email = filter["userName eq ".Length..].Trim().Trim('"');

                // ── TEMPORARY MOCK ── swap with _customerApi when ready ───────
                // GetScimUserByEmail returns full SCIM structure from dynamic store.
                // Falls back to ScimTransformer for hardcoded seed users.
                var scimUser  = MockScimService.GetScimUserByEmail(email, GetBaseUrl());
                var flexUser  = scimUser == null ? MockScimService.GetUserByEmail(email) : null;
                var resources = scimUser != null
                    ? new List<ScimUser> { scimUser }
                    : flexUser != null
                        ? new List<ScimUser> { ScimTransformer.ToScimUser(flexUser, GetBaseUrl()) }
                        : new List<ScimUser>();
                // ── END MOCK ──────────────────────────────────────────────────

                // Uncomment when Customer API is wired:
                // var user = await _customerApi.GetUserByEmailAsync(email, customerId, serviceAccount);
                // var resources = user != null
                //     ? new List<ScimUser> { ScimTransformer.ToScimUser(user, GetBaseUrl()) }
                //     : new List<ScimUser>();

                return Ok(new ScimListResponse<ScimUser>
                {
                    TotalResults = resources.Count,
                    StartIndex   = 1,
                    ItemsPerPage = resources.Count,
                    Resources    = resources
                });
            }

            _logger.LogWarning("SCIM unsupported filter received: {Filter}", filter);
            return BadRequest(new ScimError
            {
                Status   = 400,
                ScimType = "invalidFilter",
                Detail   = $"Filter '{filter}' is not supported. Only 'userName eq \"value\"' is supported."
            });
        }

        // ── TEMPORARY MOCK ── swap with _customerApi when ready ───────────────
        var (users, totalCount) = MockScimService.GetAllUsers();
        var scimUsers           = users.Select(u => ScimTransformer.ToScimUser(u, GetBaseUrl())).ToList();
        // ── END MOCK ─────────────────────────────────────────────────────────

        // Uncomment when Customer API is wired:
        // var paged      = await _customerApi.GetUsersAsync(customerId, serviceAccount, startIndex, count);
        // var totalCount = paged.TotalCount;
        // var scimUsers  = paged.Users.Select(u => ScimTransformer.ToScimUser(u, GetBaseUrl())).ToList();

        Response.Headers["X-Total-Count"] = totalCount.ToString();

        return Ok(new ScimListResponse<ScimUser>
        {
            TotalResults = totalCount,
            StartIndex   = startIndex,
            ItemsPerPage = scimUsers.Count,
            Resources    = scimUsers
        });
    }

    // POST /scim/v2/Users — create user
    [HttpPost]
    [Consumes("application/scim+json", "application/json")]
    [ProducesResponseType(typeof(ScimUser), StatusCodes.Status201Created)]
    [ProducesResponseType(typeof(ScimError), StatusCodes.Status409Conflict)]
    public async Task<IActionResult> CreateUser([FromBody] ScimUser scimUser)
    {
        var (customerId, serviceAccount) = ExtractClaims();
        _logger.LogInformation(
            "SCIM POST /Users email={Email} customer={CustomerId}", scimUser.UserName, customerId);

        // ── TEMPORARY MOCK ── duplicate guard + create ────────────────────────
        if (MockScimService.UserExists(scimUser.UserName ?? string.Empty))
            return Conflict(new ScimError
            {
                Status   = 409,
                ScimType = "uniqueness",
                Detail   = $"User {scimUser.UserName} already exists."
            });

        var created    = MockScimService.LogAndMockCreate(scimUser, _logger);
        var scimResult = MockScimService.GetScimUserByEmail(created.Email, GetBaseUrl())
                         ?? ScimTransformer.ToScimUser(created, GetBaseUrl());
        // ── END MOCK ──────────────────────────────────────────────────────────

        // Uncomment when Customer API is wired:
        // var existing = await _customerApi.GetUserByEmailAsync(
        //     scimUser.UserName ?? string.Empty, customerId, serviceAccount);
        // if (existing != null)
        //     return Conflict(new ScimError { Status = 409, ScimType = "uniqueness",
        //         Detail = $"User {scimUser.UserName} already exists." });
        // var createRequest = ScimTransformer.ToCreateRequest(scimUser, customerId, serviceAccount);
        // var created       = await _customerApi.CreateUserAsync(createRequest);
        // var scimResult    = ScimTransformer.ToScimUser(created, GetBaseUrl());

        Response.Headers["Location"] = scimResult.Meta?.Location;
        return StatusCode(201, scimResult);
    }

    // PATCH /scim/v2/Users/{id} — partial update or soft deactivate via active:false
    [HttpPatch("{id}")]
    [Consumes("application/scim+json", "application/json")]
    [ProducesResponseType(typeof(ScimUser), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ScimError), StatusCodes.Status404NotFound)]
    public async Task<IActionResult> PatchUser(string id, [FromBody] ScimPatchRequest patchRequest)
    {
        var (customerId, serviceAccount) = ExtractClaims();
        var email = Uri.UnescapeDataString(id);
        _logger.LogInformation(
            "SCIM PATCH /Users/{Email} ops={Count} customer={CustomerId}",
            email, patchRequest.Operations.Count, customerId);

        // ── TEMPORARY MOCK ─────────────────────────────────────────────────────
        var updated    = MockScimService.LogAndMockPatch(email, patchRequest, _logger);
        var scimResult = MockScimService.GetScimUserByEmail(updated.Email, GetBaseUrl())
                         ?? ScimTransformer.ToScimUser(updated, GetBaseUrl());
        // ── END MOCK ──────────────────────────────────────────────────────────

        // Uncomment when Customer API is wired:
        // var updateRequest = ScimTransformer.ApplyPatch(email, patchRequest, customerId, serviceAccount);
        // var updated       = await _customerApi.UpdateUserAsync(email, updateRequest);
        // var scimResult    = ScimTransformer.ToScimUser(updated, GetBaseUrl());

        return Ok(scimResult);
    }

    // DELETE /scim/v2/Users/{id}
    // RFC 7644 §3.6 — 204 No Content on success.
    // Mock: removes from dynamic store. Real impl: soft delete via Customer API.
    [HttpDelete("{id}")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    public IActionResult DeleteUser(string id)
    {
        var email = Uri.UnescapeDataString(id);
        _logger.LogInformation("SCIM DELETE /Users/{Email}", email);
        MockScimService.DeleteUser(email);
        return NoContent();
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    /// <summary>
    /// Reads customerId and serviceEmail from claims set by StaticBearerAuthHandler.
    /// Config-driven — no hardcoded values. New customers added via env vars only.
    /// Replace entire method with real Customer API lookup during mock cleanup pass.
    /// </summary>
    private (string customerId, string serviceAccount) ExtractClaims()
    {
        var customerId   = User.FindFirst("customerId")?.Value
                           ?? throw new UnauthorizedAccessException("Missing customerId claim");
        var serviceEmail = User.FindFirst("serviceEmail")?.Value
                           ?? throw new UnauthorizedAccessException("Missing serviceEmail claim");
        return (customerId, serviceEmail);
    }

    private string GetBaseUrl() => $"{Request.Scheme}://{Request.Host}";
}
