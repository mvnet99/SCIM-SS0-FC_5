using FlexCount.Scim.Domain.Models.FlexCount;
using FlexCount.Scim.Domain.Models.Scim;
using System.Text.RegularExpressions;

namespace FlexCount.Scim.Domain.Transformers
{

    /// <summary>
    /// Bidirectional transformer: Entra SCIM 2.0 &lt;-&gt; FlexCount schema.
    ///
    /// Entitlement rules (parsed from roles[primary=true].value):
    ///   APP-FlexCount-Corporate-User-HQ-{env}  -> Admin
    ///   APP-FlexCount-Corporate-User-{env}      -> Corporate
    ///   APP-FlexCount-Group{number}-{env}       -> Regional + groupNumber
    ///
    /// Business rules delegated to stored procedure:
    ///   - editAccessLiveEvents default (Y for all)
    ///   - overrideEventCloseout default (Y Admin, N Corporate/Regional)
    ///   - region1-4 resolution from groupNumber
    /// </summary>
    public static class ScimTransformer
    {
        private const string EntitlementPrefix = "APP-FlexCount-";

        // ── Entitlement Parsing ───────────────────────────────────────────────────

        public static ParsedEntitlement ParseEntitlement(List<ScimRole>? roles)
        {
            var role = roles?.FirstOrDefault(r => r.Primary)?.Value
                ?? roles?.FirstOrDefault()?.Value
                ?? string.Empty;

            if (string.IsNullOrEmpty(role) || !role.StartsWith(EntitlementPrefix, StringComparison.OrdinalIgnoreCase))
                throw new ArgumentException($"Missing or unrecognized entitlement role: {role}");

            // FIX #4: Extract environment suffix from last hyphen-delimited segment.
            // NOTE: fragile if env names ever contain hyphens (e.g. "East-US") — revisit if new envs added.
            var lastHyphen = role.LastIndexOf('-');
            var env = lastHyphen >= 0 ? role[(lastHyphen + 1)..] : string.Empty;
            var body = role[EntitlementPrefix.Length..];  // strip APP-FlexCount-

            // Admin: Corporate-User-HQ-{env} — checked BEFORE Corporate to avoid prefix collision
            if (body.StartsWith("Corporate-User-HQ-", StringComparison.OrdinalIgnoreCase))
                return new ParsedEntitlement { UserType = "Admin", Environment = env };

            // Corporate: Corporate-User-{env}
            if (body.StartsWith("Corporate-User-", StringComparison.OrdinalIgnoreCase))
                return new ParsedEntitlement { UserType = "Corporate", Environment = env };

            // Regional: Group{number}-{env}
            var groupMatch = Regex.Match(body, @"^Group(\d+)-", RegexOptions.IgnoreCase);
            if (groupMatch.Success)
                return new ParsedEntitlement
                {
                    UserType = "Regional",
                    GroupNumber = groupMatch.Groups[1].Value,
                    Environment = env
                };

            throw new ArgumentException($"Unrecognized entitlement format: {role}");
        }

        // ── Inbound: SCIM User -> FlexCount Create Request ────────────────────────

        public static FlexCountUserCreateRequest ToCreateRequest(
            ScimUser scimUser,
            string customerId,
            string serviceAccountEmail)
        {
            var entitlement = ParseEntitlement(scimUser.Roles);
            var email = GetPrimaryEmail(scimUser);
            var (primaryPhone, primaryPhoneType, secondaryPhone, secondaryPhoneType) = MapPhones(scimUser);

            return new FlexCountUserCreateRequest
            {
                Email = email,
                FirstName = scimUser.Name?.GivenName ?? string.Empty,
                LastName = scimUser.Name?.FamilyName ?? string.Empty,
                PrimaryPhone = primaryPhone,
                PrimaryPhoneType = primaryPhoneType,
                SecondaryPhone = secondaryPhone,
                SecondaryPhoneType = secondaryPhoneType,
                UserType = entitlement.UserType,
                GroupNumber = entitlement.GroupNumber,  // null for Admin/Corporate
                Status = scimUser.Active ? "Active" : "Inactive",
                CustomerId = customerId,
                ServiceAccountEmail = serviceAccountEmail
            };
        }

        // ── Inbound: SCIM PATCH Operations -> FlexCount Partial Update ────────────
        // No GET-first. Only fields present in operations are set.
        // null fields = Customer API / SP does not update that field.
        // FIX #3: active:false is handled here like any other field — no special-case branch needed.

        public static FlexCountUserUpdateRequest ApplyPatch(
            string email,
            ScimPatchRequest patch,
            string customerId,
            string serviceAccountEmail)
        {
            var update = new FlexCountUserUpdateRequest
            {
                CustomerId = customerId,
                ServiceAccountEmail = serviceAccountEmail
                // All other fields intentionally null
            };

            foreach (var op in patch.Operations)
            {
                var opLower = op.Op.ToLower();
                if (opLower is not ("replace" or "add" or "remove")) continue;

                var val = op.Value?.ToString();
                var path = op.Path?.ToLower() ?? string.Empty;

                switch (path)
                {
                    case "active":
                        // FIX #3: Entra sends active as a boolean JsonElement — ToString() gives "True"/"False"
                        // ToLower() + TryParse handles both "true"/"false" and "True"/"False" safely
                        update.Status = bool.TryParse(val, out var active)
                            ? (active ? "Active" : "Inactive")
                            : null;
                        break;

                    case "name.givenname":
                        update.FirstName = opLower == "remove" ? string.Empty : val;
                        break;

                    case "name.familyname":
                        update.LastName = opLower == "remove" ? string.Empty : val;
                        break;

                    case "phonenumbers[primary eq true].value":
                        update.PrimaryPhone = opLower == "remove" ? string.Empty : val;
                        break;

                    case "phonenumbers[primary eq true].type":
                        update.PrimaryPhoneType = opLower == "remove" ? string.Empty : MapPhoneType(val);
                        break;

                    case "phonenumbers[primary eq false].value":
                        update.SecondaryPhone = opLower == "remove" ? string.Empty : val;
                        break;

                    case "phonenumbers[primary eq false].type":
                        update.SecondaryPhoneType = opLower == "remove" ? string.Empty : MapPhoneType(val);
                        break;

                    case "roles":
                        if (op.Value is System.Text.Json.JsonElement je)
                        {
                            var roles = ParseRolesFromJson(je);
                            if (roles.Any())
                            {
                                var entitlement = ParseEntitlement(roles);
                                update.UserType = entitlement.UserType;
                                update.GroupNumber = entitlement.GroupNumber;
                            }
                        }
                        break;
                }
            }

            return update;
        }

        // ── Soft Delete via PATCH active:false ────────────────────────────────────
        // FIX #12: email param left as-is — harmless, may be useful for future logging

        public static FlexCountUserUpdateRequest BuildSoftDelete(
            string email,
            string customerId,
            string serviceAccountEmail)
        {
            return new FlexCountUserUpdateRequest
            {
                Status = "Inactive",
                CustomerId = customerId,
                ServiceAccountEmail = serviceAccountEmail
            };
        }

        // ── Outbound: FlexCount User -> SCIM User ─────────────────────────────────
        // FIX #11: ExternalId NOT set — left null. Do not map email to ExternalId.
        // Entra OID not stored in FlexCount today — setting email caused identity mismatch risk.

        public static ScimUser ToScimUser(FlexCountUser user, string baseUrl)
        {
            return new ScimUser
            {
                Id = user.Email,
                ExternalId = null,   // FIX #11: intentionally null — not set to email
                UserName = user.Email,
                Name = new ScimName
                {
                    GivenName = user.FirstName,
                    FamilyName = user.LastName
                },
                Emails = new List<ScimEmail>
            {
                new() { Value = user.Email, Type = "work", Primary = true }
            },
                PhoneNumbers = BuildScimPhones(user),
                Active = user.Status == "Active",
                Roles = new List<ScimRole>
            {
                new() { Value = user.UserType, Primary = true }
            },
                Meta = new ScimMeta
                {
                    ResourceType = "User",
                    Created = user.CreatedAt ?? DateTime.UtcNow,
                    LastModified = user.UpdatedAt ?? DateTime.UtcNow,
                    Location = $"{baseUrl}/scim/v2/Users/{Uri.EscapeDataString(user.Email)}",
                    Version = $"W/\"{user.UpdatedAt?.Ticks}\""
                }
            };
        }

        // ── Private Helpers ───────────────────────────────────────────────────────

        private static string GetPrimaryEmail(ScimUser user) =>
            user.Emails?.FirstOrDefault(e => e.Primary)?.Value
            ?? user.Emails?.FirstOrDefault()?.Value
            ?? user.UserName
            ?? string.Empty;

        private static (string? primary, string? primaryType, string? secondary, string? secondaryType)
            MapPhones(ScimUser user)
        {
            if (user.PhoneNumbers == null || !user.PhoneNumbers.Any())
                return (null, null, null, null);

            var primary = user.PhoneNumbers.FirstOrDefault(p => p.Primary);
            var secondary = user.PhoneNumbers.FirstOrDefault(p => !p.Primary);

            return (
                primary?.Value,
                MapPhoneType(primary?.Type),
                secondary?.Value,
                MapPhoneType(secondary?.Type)
            );
        }

        private static string? MapPhoneType(string? scimType) => scimType?.ToLower() switch
        {
            "mobile" or "cell" => "Mobile",
            "home" => "Home",
            "work" or "office" => "Office",
            _ => null
        };

        private static List<ScimPhoneNumber> BuildScimPhones(FlexCountUser user)
        {
            var phones = new List<ScimPhoneNumber>();
            if (!string.IsNullOrEmpty(user.PrimaryPhone))
                phones.Add(new ScimPhoneNumber
                {
                    Value = user.PrimaryPhone,
                    Type = MapPhoneTypeToScim(user.PrimaryPhoneType),
                    Primary = true
                });
            if (!string.IsNullOrEmpty(user.SecondaryPhone))
                phones.Add(new ScimPhoneNumber
                {
                    Value = user.SecondaryPhone,
                    Type = MapPhoneTypeToScim(user.SecondaryPhoneType),
                    Primary = false
                });
            return phones;
        }

        private static string? MapPhoneTypeToScim(string? flexType) => flexType?.ToLower() switch
        {
            "mobile" => "mobile",
            "home" => "home",
            "office" => "work",
            _ => null
        };

        private static List<ScimRole> ParseRolesFromJson(System.Text.Json.JsonElement je)
        {
            var roles = new List<ScimRole>();
            try
            {
                if (je.ValueKind == System.Text.Json.JsonValueKind.Array)
                {
                    foreach (var item in je.EnumerateArray())
                    {
                        var value = item.TryGetProperty("value", out var v) ? v.GetString() : null;
                        var primary = item.TryGetProperty("primary", out var p) && p.GetBoolean();
                        if (value != null)
                            roles.Add(new ScimRole { Value = value, Primary = primary });
                    }
                }
            }
            catch { /* ignore malformed roles */ }
            return roles;
        }
    }
}
