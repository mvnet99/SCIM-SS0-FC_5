﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace FlexCount.Scim.Domain.Models.Scim
{
    public class ScimUser
    {
        public List<string> Schemas { get; set; } = new()
    {
        "urn:ietf:params:scim:schemas:core:2.0:User"
    };

        public string? Id { get; set; }       // email — immutable identifier
        public string? ExternalId { get; set; }       // FIX #11: not set — leave null (not email)
        public string? UserName { get; set; }       // email
        public ScimName? Name { get; set; }
        public List<ScimEmail>? Emails { get; set; }
        public List<ScimPhoneNumber>? PhoneNumbers { get; set; }
        public bool Active { get; set; } = true;  // maps to status: Active/Inactive
        public List<ScimRole>? Roles { get; set; }        // entitlement carrier
        public ScimMeta? Meta { get; set; }
    }

    public class ScimName
    {
        public string? GivenName { get; set; }
        public string? FamilyName { get; set; }
    }

    public class ScimEmail
    {
        public string? Value { get; set; }
        public string? Type { get; set; }

        [System.Text.Json.Serialization.JsonConverter(typeof(BooleanStringConverter))]
        public bool Primary { get; set; }
    }

    public class ScimPhoneNumber
    {
        public string? Value { get; set; }
        public string? Type { get; set; }   // mobile, home, work -> Mobile, Home, Office

        [System.Text.Json.Serialization.JsonConverter(typeof(BooleanStringConverter))]
        public bool Primary { get; set; }
    }

    public class ScimRole
    {
        public string? Value { get; set; }  // e.g. APP-FlexCount-Group195-Prod
        public string? Display { get; set; }

        [System.Text.Json.Serialization.JsonConverter(typeof(BooleanStringConverter))]
        public bool Primary { get; set; }
    }

    public class ScimMeta
    {
        public string ResourceType { get; set; } = "User";
        public DateTime Created { get; set; }
        public DateTime LastModified { get; set; }
        public string? Location { get; set; }
        public string? Version { get; set; }
    }

    // ── List Response ─────────────────────────────────────────────────────────────

    public class ScimListResponse<T>
    {
        public List<string> Schemas { get; set; } = new() { "urn:ietf:params:scim:api:messages:2.0:ListResponse" };
        public int TotalResults { get; set; }
        public int StartIndex { get; set; } = 1;
        public int ItemsPerPage { get; set; }

        [JsonPropertyName("Resources")]
        public List<T> Resources { get; set; } = new();
    }

    // ── PATCH ─────────────────────────────────────────────────────────────────────

    public class ScimPatchRequest
    {
        public List<string> Schemas { get; set; } = new() { "urn:ietf:params:scim:api:messages:2.0:PatchOp" };
        public List<ScimPatchOperation> Operations { get; set; } = new();
    }

    public class ScimPatchOperation
    {
        public string Op { get; set; } = string.Empty;  // add | remove | replace
        public string? Path { get; set; }
        public object? Value { get; set; }
    }

    // ── Error ─────────────────────────────────────────────────────────────────────

    public class ScimError
    {
        public List<string> Schemas { get; set; } = new() { "urn:ietf:params:scim:api:messages:2.0:Error" };
        public string? Detail { get; set; }
        public int Status { get; set; }
        public string? ScimType { get; set; }
    }

    public class BooleanStringConverter : JsonConverter<bool>
    {
        public override bool Read(ref Utf8JsonReader reader,
                    Type typeToConvert, JsonSerializerOptions options)
        {
            if (reader.TokenType == JsonTokenType.String)
            {
                var str = reader.GetString();
                return str != null && (str.Equals("true", StringComparison.OrdinalIgnoreCase) || str.Equals("1"));
            }
            else if (reader.TokenType == JsonTokenType.Number)
            {
                return reader.GetInt32() == 1;
            }
            else if (reader.TokenType == JsonTokenType.True)
            {
                return true;
            }
            else if (reader.TokenType == JsonTokenType.False)
            {
                return false;
            }
            throw new JsonException($"Unexpected token parsing boolean. Expected String or Number, got {reader.TokenType}.");
        }
        public override void Write(Utf8JsonWriter writer, bool value, JsonSerializerOptions options)
        {
            //writer.WriteBooleanValue(value);
            writer.WriteStringValue(value ? "true" : "false");
        }

    }
}
