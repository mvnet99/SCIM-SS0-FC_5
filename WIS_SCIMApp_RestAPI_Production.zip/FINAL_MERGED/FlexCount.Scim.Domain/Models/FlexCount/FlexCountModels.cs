﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlexCount.Scim.Domain.Models.FlexCount
{
    public class FlexCountUser
    {
        public string? Id { get; set; }
        public string Email { get; set; } = string.Empty;
        public string FirstName { get; set; } = string.Empty;
        public string LastName { get; set; } = string.Empty;
        public string? PrimaryPhone { get; set; }
        public string? PrimaryPhoneType { get; set; }   // Mobile | Home | Office
        public string? SecondaryPhone { get; set; }
        public string? SecondaryPhoneType { get; set; }
        public string UserType { get; set; } = string.Empty;  // Admin | Corporate | Regional
        public string Status { get; set; } = "Active";       // Active | Inactive
        public DateTime? CreatedAt { get; set; }
        public DateTime? UpdatedAt { get; set; }
    }

    // ── Create Request (POST) ─────────────────────────────────────────────────────
    // editAccessLiveEvents, overrideEventCloseout, region1-4 resolved in stored procedure
    // groupNumber passed for Regional — SP uses it to resolve region values

    public class FlexCountUserCreateRequest
    {
        public string Email { get; set; } = string.Empty;
        public string FirstName { get; set; } = string.Empty;
        public string LastName { get; set; } = string.Empty;
        public string? PrimaryPhone { get; set; }
        public string? PrimaryPhoneType { get; set; }
        public string? SecondaryPhone { get; set; }
        public string? SecondaryPhoneType { get; set; }
        public string UserType { get; set; } = string.Empty;
        public string? GroupNumber { get; set; }   // Regional only — SP resolves to region1-4
        public string Status { get; set; } = "Active";
        public string CustomerId { get; set; } = string.Empty;
        public string ServiceAccountEmail { get; set; } = string.Empty;
    }

    // ── Update Request (PATCH) ────────────────────────────────────────────────────
    // All fields nullable — Customer API / SP ignores null fields (do not update)
    // groupNumber nullable — only set if entitlement changes on a Regional user

    public class FlexCountUserUpdateRequest
    {
        public string? FirstName { get; set; }
        public string? LastName { get; set; }
        public string? PrimaryPhone { get; set; }
        public string? PrimaryPhoneType { get; set; }
        public string? SecondaryPhone { get; set; }
        public string? SecondaryPhoneType { get; set; }
        public string? UserType { get; set; }
        public string? GroupNumber { get; set; }   // Regional only — nullable
        public string? Status { get; set; }   // Active | Inactive — null = do not update
        public string CustomerId { get; set; } = string.Empty;
        public string ServiceAccountEmail { get; set; } = string.Empty;
    }

    // ── Paged Result ──────────────────────────────────────────────────────────────

    public class FlexCountPagedResult
    {
        public int TotalCount { get; set; }
        public int StartIndex { get; set; }
        public int Count { get; set; }
        public List<FlexCountUser> Users { get; set; } = new();
    }

    // ── Entitlement Parsing Result ────────────────────────────────────────────────

    public class ParsedEntitlement
    {
        public string UserType { get; set; } = string.Empty;   // Admin | Corporate | Regional
        public string? GroupNumber { get; set; }                    // Regional only
        public string Environment { get; set; } = string.Empty;   // Prod | Dev
    }
}
