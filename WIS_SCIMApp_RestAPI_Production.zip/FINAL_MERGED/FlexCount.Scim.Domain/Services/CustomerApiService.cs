using FlexCount.Scim.Domain.Models.FlexCount;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System.Collections.Concurrent;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;

namespace FlexCount.Scim.Domain.Services;

/// <summary>
/// Outbound HTTP service: SCIM API → Customer API via APIM.
///
/// Authentication: OAuth 2.0 Client Credentials flow.
/// Both SCIM API and Customer API are registered on the same B2C tenant
/// (flexcountdev / 281fc3c7...). No main WIS AD tenant dependency.
///
/// Token flow:
///   SCIM App Registration (f32bc1e6) requests token from B2C tenant
///   → scope: api://2d6cabcf.../.default (Customer API App Registration)
///   → token sent as Bearer on every outbound request
///   → Customer API validates via ScimOAuth scheme in Startup.cs
///
/// Token caching: internal cache prevents redundant token requests.
/// All secrets stored in Key Vault — injected as Container App env vars by SRE.
/// </summary>
public class CustomerApiService : ICustomerApiService
{
    private readonly HttpClient _httpClient;
    private readonly ILogger<CustomerApiService> _logger;
    private readonly string _baseUrl;
    private readonly string _tenantId;
    private readonly string _clientId;
    private readonly string _clientSecret;
    private readonly string _scope;

    // ── Token cache — avoids hitting token endpoint on every API call ─────────
    private static string?   _cachedToken;
    private static DateTime  _tokenExpiry = DateTime.MinValue;
    private static readonly SemaphoreSlim _tokenLock = new(1, 1);

    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        PropertyNamingPolicy        = JsonNamingPolicy.CamelCase,
        PropertyNameCaseInsensitive = true,
        DefaultIgnoreCondition      = System.Text.Json.Serialization.JsonIgnoreCondition.WhenWritingNull
    };

    public CustomerApiService(
        HttpClient httpClient,
        IConfiguration configuration,
        ILogger<CustomerApiService> logger)
    {
        _httpClient   = httpClient;
        _logger       = logger;

        _baseUrl      = configuration["CustomerApi:BaseUrl"]
            ?? throw new InvalidOperationException("CustomerApi:BaseUrl is not configured");
        _tenantId     = configuration["CustomerApi:TenantId"]
            ?? throw new InvalidOperationException("CustomerApi:TenantId is not configured");
        _clientId     = configuration["CustomerApi:ClientId"]
            ?? throw new InvalidOperationException("CustomerApi:ClientId is not configured");
        _clientSecret = configuration["CustomerApi:ClientSecret"]
            ?? throw new InvalidOperationException("CustomerApi:ClientSecret is not configured");
        _scope        = configuration["CustomerApi:Scope"]
            ?? throw new InvalidOperationException("CustomerApi:Scope is not configured");
    }

    public async Task<FlexCountUser?> GetUserByEmailAsync(
        string email, string customerId, string serviceAccountEmail)
    {
        var request = new HttpRequestMessage(HttpMethod.Get,
            $"{_baseUrl}/api/users?email={Uri.EscapeDataString(email)}");

        await SetAuthHeaderAsync(request);
        AddContextHeaders(request, customerId, serviceAccountEmail);

        _logger.LogInformation(
            "CustomerAPI GET user email={Email} customer={CustomerId}", email, customerId);

        var response = await _httpClient.SendAsync(request);
        if (response.StatusCode == System.Net.HttpStatusCode.NotFound) return null;
        response.EnsureSuccessStatusCode();
        return await DeserializeAsync<FlexCountUser>(response);
    }

    public async Task<FlexCountPagedResult> GetUsersAsync(
        string customerId, string serviceAccountEmail, int startIndex = 1, int count = 100)
    {
        var request = new HttpRequestMessage(HttpMethod.Get,
            $"{_baseUrl}/api/users?startIndex={startIndex}&count={count}");

        await SetAuthHeaderAsync(request);
        AddContextHeaders(request, customerId, serviceAccountEmail);

        _logger.LogInformation(
            "CustomerAPI GET users paged startIndex={StartIndex} count={Count} customer={CustomerId}",
            startIndex, count, customerId);

        var response = await _httpClient.SendAsync(request);
        response.EnsureSuccessStatusCode();
        return await DeserializeAsync<FlexCountPagedResult>(response) ?? new FlexCountPagedResult();
    }

    public async Task<FlexCountUser> CreateUserAsync(FlexCountUserCreateRequest createRequest)
    {
        var httpRequest = new HttpRequestMessage(HttpMethod.Post, $"{_baseUrl}/api/users")
        {
            Content = new StringContent(
                JsonSerializer.Serialize(createRequest, JsonOptions),
                Encoding.UTF8, "application/json")
        };

        await SetAuthHeaderAsync(httpRequest);
        AddContextHeaders(httpRequest, createRequest.CustomerId, createRequest.ServiceAccountEmail);

        _logger.LogInformation(
            "CustomerAPI POST user email={Email} userType={UserType} customer={CustomerId}",
            createRequest.Email, createRequest.UserType, createRequest.CustomerId);

        var response = await _httpClient.SendAsync(httpRequest);
        response.EnsureSuccessStatusCode();
        return await DeserializeAsync<FlexCountUser>(response)
            ?? throw new InvalidOperationException("Empty response from Customer API on create");
    }

    public async Task<FlexCountUser> UpdateUserAsync(
        string email, FlexCountUserUpdateRequest updateRequest)
    {
        var httpRequest = new HttpRequestMessage(HttpMethod.Patch,
            $"{_baseUrl}/api/users/{Uri.EscapeDataString(email)}")
        {
            Content = new StringContent(
                JsonSerializer.Serialize(updateRequest, JsonOptions),
                Encoding.UTF8, "application/json")
        };

        await SetAuthHeaderAsync(httpRequest);
        AddContextHeaders(httpRequest, updateRequest.CustomerId, updateRequest.ServiceAccountEmail);

        _logger.LogInformation(
            "CustomerAPI PATCH user email={Email} status={Status} customer={CustomerId}",
            email, updateRequest.Status, updateRequest.CustomerId);

        var response = await _httpClient.SendAsync(httpRequest);
        response.EnsureSuccessStatusCode();
        return await DeserializeAsync<FlexCountUser>(response)
            ?? throw new InvalidOperationException("Empty response from Customer API on update");
    }

    // ── Private Helpers ───────────────────────────────────────────────────────

    /// <summary>
    /// Acquires OAuth Client Credentials token from B2C tenant.
    /// Token is cached until 5 minutes before expiry to avoid redundant calls.
    /// Set per HttpRequestMessage — never on DefaultRequestHeaders (thread safety).
    /// </summary>
    private async Task SetAuthHeaderAsync(HttpRequestMessage request)
    {
        var token = await GetOrRefreshTokenAsync();
        request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);
    }

    private async Task<string> GetOrRefreshTokenAsync()
    {
        // Return cached token if still valid (with 5 min buffer)
        if (_cachedToken != null && DateTime.UtcNow < _tokenExpiry)
            return _cachedToken;

        await _tokenLock.WaitAsync();
        try
        {
            // Double-check after acquiring lock
            if (_cachedToken != null && DateTime.UtcNow < _tokenExpiry)
                return _cachedToken;

            _logger.LogInformation(
                "Acquiring OAuth token from B2C tenant for Customer API");

            var tokenEndpoint =
                $"https://login.microsoftonline.com/{_tenantId}/oauth2/v2.0/token";

            var body = new FormUrlEncodedContent(new[]
            {
                new KeyValuePair<string, string>("grant_type",    "client_credentials"),
                new KeyValuePair<string, string>("client_id",     _clientId),
                new KeyValuePair<string, string>("client_secret", _clientSecret),
                new KeyValuePair<string, string>("scope",         _scope)
            });

            var response = await _httpClient.PostAsync(tokenEndpoint, body);
            response.EnsureSuccessStatusCode();

            var json    = await response.Content.ReadAsStringAsync();
            var result  = JsonSerializer.Deserialize<TokenResponse>(json)
                ?? throw new InvalidOperationException("Empty token response");

            _cachedToken = result.AccessToken;
            // Cache for token lifetime minus 5 min buffer
            _tokenExpiry = DateTime.UtcNow.AddSeconds(result.ExpiresIn - 300);

            return _cachedToken;
        }
        finally
        {
            _tokenLock.Release();
        }
    }

    private static void AddContextHeaders(
        HttpRequestMessage request, string customerId, string serviceAccountEmail)
    {
        request.Headers.Add("X-Customer-Id",     customerId);
        request.Headers.Add("X-Service-Account", serviceAccountEmail);
    }

    private static async Task<T?> DeserializeAsync<T>(HttpResponseMessage response)
    {
        var json = await response.Content.ReadAsStringAsync();
        return JsonSerializer.Deserialize<T>(json, JsonOptions);
    }

    // ── Token response model ──────────────────────────────────────────────────
    private sealed class TokenResponse
    {
        [System.Text.Json.Serialization.JsonPropertyName("access_token")]
        public string AccessToken { get; set; } = string.Empty;

        [System.Text.Json.Serialization.JsonPropertyName("expires_in")]
        public int ExpiresIn { get; set; }
    }
}
