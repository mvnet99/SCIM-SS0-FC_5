﻿using FlexCount.Scim.Domain.Models.FlexCount;


namespace FlexCount.Scim.Domain.Services
{

    public interface ICustomerApiService
    {
        Task<FlexCountUser?> GetUserByEmailAsync(string email, string customerId, string serviceAccountEmail);
        Task<FlexCountPagedResult> GetUsersAsync(string customerId, string serviceAccountEmail, int startIndex = 1, int count = 100);
        Task<FlexCountUser> CreateUserAsync(FlexCountUserCreateRequest request);
        Task<FlexCountUser> UpdateUserAsync(string email, FlexCountUserUpdateRequest request);
    }

}
