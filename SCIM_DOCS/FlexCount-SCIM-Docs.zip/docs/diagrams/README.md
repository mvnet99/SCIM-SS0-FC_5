# Diagrams

## `scim-azure-infrastructure.drawio`

The Azure infrastructure picture. **This file is the source of truth.**

### To view or edit

- **Browser:** go to [app.diagrams.net](https://app.diagrams.net) → File → Open from → Device
- **VS Code:** install the *Draw.io Integration* extension, then just open the file

No account needed either way.

### To update the wiki

1. Edit the `.drawio`
2. File → Export as → PNG, with **Transparent Background off** and **Zoom 200%**
3. Save it here as `scim-azure-infrastructure.png`
4. Commit both files

The PNG is only there so the wiki has something to render. Never edit the PNG — always the `.drawio`.

### Why this one isn't Mermaid

Azure DevOps renders Mermaid, but it's pinned to an old version with limited syntax support — no icon support. Everything about *flow* is Mermaid, inline in `02-architecture.md`, because it diffs in pull requests. This one diagram uses draw.io because Azure icons genuinely help on an infrastructure picture, and draw.io is free, keeps the source in the repo, and needs no licence.
